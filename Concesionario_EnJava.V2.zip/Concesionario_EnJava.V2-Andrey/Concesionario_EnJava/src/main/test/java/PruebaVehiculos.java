public class PruebaVehiculos {
}
