package modelo;

public class Transaccion {

    private TipoTransaccion transaccion;
    private Empleado empleaado;
}
