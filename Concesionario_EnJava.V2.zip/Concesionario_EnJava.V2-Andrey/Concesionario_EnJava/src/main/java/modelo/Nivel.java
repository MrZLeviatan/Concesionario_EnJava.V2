package modelo;

public enum Nivel {
    SUPERIOR,
    INFERIOR
}
