package modelo;

public enum Combustible {
    GASOLINA,
    DIESEL,
    ELECTRICOS,
    HIBRIDOS
}
