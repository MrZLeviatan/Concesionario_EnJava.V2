package modelo;

public enum Genero {

    MASCULINO,
    FEMENINO,
    OTROS
}
