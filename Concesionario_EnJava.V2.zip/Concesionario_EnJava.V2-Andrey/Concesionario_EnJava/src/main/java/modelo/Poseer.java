package modelo;

public enum Poseer {
    NOPOSEE,
    POSEER
}
