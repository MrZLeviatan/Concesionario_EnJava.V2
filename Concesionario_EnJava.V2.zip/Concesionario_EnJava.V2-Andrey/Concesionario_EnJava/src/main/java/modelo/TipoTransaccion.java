package modelo;

public enum TipoTransaccion {

    VENTA,
    RENTA,
    ALQUILER
}
