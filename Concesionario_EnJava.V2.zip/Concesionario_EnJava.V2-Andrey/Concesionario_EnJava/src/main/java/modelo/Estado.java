package modelo;

public enum Estado {
    ACTIVO,
    INACTIVO
}
