package modelo;

public enum EstadoUso {
    USADO,
    NOUSADO
}
