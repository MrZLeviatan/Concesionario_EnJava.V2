package modelo;


public enum TipoCamion {
    DECEPTICON,
    AUTOBOT,
    MAXIMAL,
    DINOBOTS,
    PREDACONS
    
    
}
