package modelo;

public enum Transmision {

    MANUAL,
    AUTOMATICA
}
